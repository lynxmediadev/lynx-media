// ================================================
// File: src/components/ui/AudioPlayer.tsx
// Reusable, elegant, two‑row player (Grid). Shadcn + Tailwind v4.
// ================================================
"use client";

import * as React from "react";
import Image from "next/image";
import Link from "next/link";
import { cn } from "@/lib/utils";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// If you don't have DropdownMenu yet, run: npx shadcn@latest add dropdown-menu
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

import {
  PlayIcon,
  PauseIcon,
  Heart,
  UserRound,
  FileText,
  Share2,
  Plus,
  Info,
  DownloadCloud,
  Copy,
} from "lucide-react";

// --------------------------------
// Types
// --------------------------------
export type PlayerRights = {
  master?: string;
  publishingSplit?: string;
  licenseType?: string;
  territories?: string;
  term?: string;
  scope?: string[];
  mediaBuy?: string;
  mfn?: boolean;
  restrictions?: string[];
  contentID?: { enrolled?: boolean; admin?: string; whitelist?: string };
};

export type PlayerIdentifiers = {
  isrc?: string;
  iswc?: string;
  upc?: string;
};

export type PlayerTrack = {
  id: string;
  title: string;
  artist: string;
  audioUrl: string;
  coverUrl?: string;
  moods?: string[];
  uses?: string[]; // TV, Cine, Publicidad, Trailers, Games, Social, Online
  shareUrl?: string;
  artistUrl?: string;
  rights?: PlayerRights;
  identifiers?: PlayerIdentifiers;
};

export type AudioPlayerProps = {
  track: PlayerTrack;
  className?: string;
  onFavorite?: (track: PlayerTrack, liked: boolean) => void;
};

// --------------------------------
// Helpers
// --------------------------------
function fmt(t: number): string {
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
}

// --------------------------------
// Component
// --------------------------------
export function AudioPlayer({
  track,
  className,
  onFavorite,
}: AudioPlayerProps) {
  const audioRef = React.useRef<HTMLAudioElement | null>(null);
  const [ready, setReady] = React.useState(false);
  const [playing, setPlaying] = React.useState(false);
  const [liked, setLiked] = React.useState(false);
  const [copied, setCopied] = React.useState(false);

  const [duration, setDuration] = React.useState(0);
  const [current, setCurrent] = React.useState(0);
  const [seeking, setSeeking] = React.useState(false);
  const [seekValue, setSeekValue] = React.useState(0);

  React.useEffect(() => {
    const el = audioRef.current;
    if (!el) return;

    const onLoaded = () => {
      setDuration(el.duration || 0);
      setReady(true);
    };
    const onTime = () => {
      if (!seeking) setCurrent(el.currentTime || 0);
    };
    const onEnded = () => {
      setPlaying(false);
      setCurrent(0);
    };

    el.addEventListener("loadedmetadata", onLoaded);
    el.addEventListener("timeupdate", onTime);
    el.addEventListener("ended", onEnded);
    return () => {
      el.removeEventListener("loadedmetadata", onLoaded);
      el.removeEventListener("timeupdate", onTime);
      el.removeEventListener("ended", onEnded);
    };
  }, [seeking]);

  function togglePlay() {
    const el = audioRef.current;
    if (!el) return;
    if (playing) {
      el.pause();
      setPlaying(false);
    } else {
      el.play()
        .then(() => setPlaying(true))
        .catch(() => {});
    }
  }

  function onSeekChange(vals: number[]) {
    const v = vals[0] ?? 0;
    setSeekValue(v);
  }
  function onSeekStart() {
    setSeeking(true);
  }
  function onSeekCommit(vals: number[]) {
    const v = vals[0] ?? 0;
    const el = audioRef.current;
    if (!el) return;
    el.currentTime = v;
    setCurrent(v);
    setSeeking(false);
  }

  const progress = seeking ? seekValue : current;

  return (
    <TooltipProvider>
      <div
        className={cn(
          "border-border/80 w-full rounded-xl border bg-[color:var(--color-dark)] text-[color:var(--color-light)]/95 shadow-sm",
          "px-3 py-2 sm:px-4 sm:py-3",
          "grid gap-x-3 gap-y-2",
          // 2 filas: top (contenido), bottom (barra + tags)
          "grid-cols-[auto_1fr_auto] grid-rows-[auto_auto]",
          className,
        )}
      >
        {/* Cover + Play */}
        <div className="col-start-1 col-end-2 row-span-2 flex items-center">
          <div className="border-border/70 relative h-14 w-14 overflow-hidden rounded-lg border sm:h-16 sm:w-16">
            {track.coverUrl ? (
              <Image
                src={track.coverUrl}
                alt={track.title}
                fill
                sizes="64px"
                className="object-cover"
              />
            ) : (
              <div className="text-muted-foreground/80 absolute inset-0 grid place-items-center text-sm">
                Cover
              </div>
            )}
            <Button
              size="icon"
              variant="secondary"
              aria-label={playing ? "Pausar" : "Reproducir"}
              className="bg-background/70 hover:bg-background absolute inset-0 m-auto flex h-12 w-12 items-center justify-center rounded-full shadow-md"
              onClick={togglePlay}
            >
              {playing ? (
                <PauseIcon className="h-4 w-4" />
              ) : (
                <PlayIcon className="h-4 w-4 translate-x-[1px]" />
              )}
            </Button>
          </div>
        </div>

        {/* Título / Artista (fila 1, centro) */}
        <div className="col-start-2 col-end-3 row-start-1 row-end-2 flex min-w-0 items-center">
          <div className="min-w-0">
            <div className="truncate text-[15px] leading-tight font-semibold sm:text-[15.5px]">
              {track.title}
            </div>
            <div className="text-muted-foreground mt-0.5 truncate text-[13px]">
              {track.artist}
            </div>
          </div>
        </div>

        {/* Botones de acción (fila 1, derecha) */}
        <div className="col-start-3 col-end-4 row-start-1 row-end-2 flex items-center gap-1.5 sm:gap-2">
          {/* Favoritos */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                aria-label={
                  liked ? "Quitar de favoritos" : "Agregar a favoritos"
                }
                className={cn("h-8 w-8 rounded-md", liked && "bg-primary/10")}
                onClick={() => {
                  const next = !liked;
                  setLiked(next);
                  onFavorite?.(track, next);
                }}
              >
                <Heart
                  className={cn("h-4 w-4", liked ? "fill-current" : undefined)}
                />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              {liked ? "Quitar de favoritos" : "Agregar a favoritos"}
            </TooltipContent>
          </Tooltip>

          {/* Más del artista */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                aria-label="Más del artista"
                asChild
              >
                <Link href={track.artistUrl || "#"}>
                  <UserRound className="h-4 w-4" />
                </Link>
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">Más del artista</TooltipContent>
          </Tooltip>

          {/* Licencias */}
          <Dialog>
            <Tooltip>
              <TooltipTrigger asChild>
                <DialogTrigger asChild>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Licencias"
                    className="h-8 w-8 rounded-md"
                  >
                    <FileText className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
              </TooltipTrigger>
              <TooltipContent side="bottom">Licencias</TooltipContent>
            </Tooltip>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Licencias — {track.title}</DialogTitle>
                <DialogDescription>
                  Resumen para supervisores. Pide términos completos si lo
                  requieres.
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 text-[14.5px]">
                <div>
                  <p className="text-muted-foreground text-[12px]">Master</p>
                  <p className="font-medium">{track.rights?.master ?? "—"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-[12px]">
                    Publishing
                  </p>
                  <p className="font-medium">
                    {track.rights?.publishingSplit ?? "—"}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground text-[12px]">Tipo</p>
                  <p className="font-medium">
                    {track.rights?.licenseType ?? "—"}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground text-[12px]">
                    Territorios
                  </p>
                  <p className="font-medium">
                    {track.rights?.territories ?? "—"}
                  </p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-[12px]">
                    Restricciones
                  </p>
                  <p className="font-medium">
                    {(track.rights?.restrictions ?? []).join(", ") || "Ninguna"}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground text-[12px]">
                    Content ID
                  </p>
                  <p className="font-medium">
                    {track.rights?.contentID?.enrolled
                      ? `Enrolado (${track.rights?.contentID?.admin ?? "—"})`
                      : "No enrolado"}
                  </p>
                </div>
              </div>
              <div className="text-muted-foreground mt-2 text-[13.5px]">
                ¿Necesitas medios/periodo/exclusividad/media buy? Escríbenos a{" "}
                {track.rights?.contentID?.whitelist ?? "licensing@lynxmedia.cl"}
              </div>
            </DialogContent>
          </Dialog>

          {/* Contacto */}
          <Dialog>
            <Tooltip>
              <TooltipTrigger asChild>
                <DialogTrigger asChild>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Contacto"
                    className="h-8 w-8 rounded-md"
                  >
                    <Info className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
              </TooltipTrigger>
              <TooltipContent side="bottom">Contacto</TooltipContent>
            </Tooltip>
            <DialogContent className="sm:max-w-lg">
              <DialogHeader>
                <DialogTitle>Contacto — {track.title}</DialogTitle>
                <DialogDescription>
                  Cuéntanos del proyecto para cotizar/licenciar rápidamente.
                </DialogDescription>
              </DialogHeader>
              <form
                className="grid gap-3 text-[14.5px]"
                onSubmit={(e) => {
                  e.preventDefault();
                  // TODO: hook to API / email action
                }}
              >
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="usage">Uso</Label>
                    <Select defaultValue="Publicidad">
                      <SelectTrigger id="usage" className="mt-1">
                        <SelectValue placeholder="Selecciona" />
                      </SelectTrigger>
                      <SelectContent>
                        {[
                          "TV",
                          "Cine",
                          "Publicidad",
                          "Documental",
                          "Trailers",
                          "Videojuegos",
                          "Redes sociales",
                          "YouTube/Twitch",
                          "App/UX",
                        ].map((u) => (
                          <SelectItem key={u} value={u}>
                            {u}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="meeting">¿Reunión?</Label>
                    <div className="mt-2 flex items-center gap-2">
                      <Checkbox id="meeting" />
                      <span className="text-muted-foreground text-[13.5px]">
                        Solicitar reunión breve
                      </span>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="name">Nombre</Label>
                    <Input id="name" className="mt-1" required />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" className="mt-1" required />
                  </div>
                </div>
                <div>
                  <Label htmlFor="details">Detalles</Label>
                  <Textarea
                    id="details"
                    className="mt-1"
                    placeholder="Duración del uso, territorio, presupuesto (opcional)"
                    rows={4}
                  />
                </div>
                <div className="flex justify-end">
                  <Button type="submit">Enviar</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          {/* Compartir */}
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                size="icon"
                variant="ghost"
                aria-label="Compartir"
                className="h-8 w-8 rounded-md"
                onClick={() => {
                  const url =
                    track.shareUrl || globalThis?.location?.href || "";
                  navigator.clipboard.writeText(url).catch(() => {});
                  setCopied(true);
                  setTimeout(() => setCopied(false), 1200);
                }}
              >
                <Share2 className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">
              {copied ? "¡Copiado!" : "Copiar enlace"}
            </TooltipContent>
          </Tooltip>

          {/* Utilidades (+) */}
          <DropdownMenu>
            <Tooltip>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label="Utilidades"
                    className="h-8 w-8 rounded-md"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <TooltipContent side="bottom">Más acciones</TooltipContent>
            </Tooltip>
            <DropdownMenuContent align="end" className="min-w-52">
              <DropdownMenuItem asChild>
                <a href={track.audioUrl} download>
                  <DownloadCloud className="mr-2 h-4 w-4" /> Descargar preview
                </a>
              </DropdownMenuItem>
              {track.identifiers?.isrc ? (
                <DropdownMenuItem
                  onClick={() =>
                    navigator.clipboard
                      .writeText(track.identifiers!.isrc || "")
                      .catch(() => {})
                  }
                >
                  <Copy className="mr-2 h-4 w-4" /> Copiar ISRC
                </DropdownMenuItem>
              ) : null}
              <DropdownMenuItem asChild>
                <Link href="/catalog">Abrir ficha técnica</Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Tags (fila 2, centro) */}
        <div className="col-start-2 col-end-3 row-start-2 row-end-3 flex flex-wrap items-center gap-1.5">
          {(track.moods ?? []).map((m) => (
            <Badge
              key={m}
              variant="secondary"
              className="rounded-full text-[11px]"
            >
              {m}
            </Badge>
          ))}
          {(track.uses ?? []).map((u) => (
            <Badge key={u} className="rounded-full text-[11px]">
              {u}
            </Badge>
          ))}
        </div>

        {/* Barra de progreso + tiempo (fila 2, derecha) */}
        <div className="col-start-3 col-end-4 row-start-2 row-end-3 flex min-w-[10rem] items-center gap-2">
          <div className="text-muted-foreground w-[3.5rem] text-right text-[12px] tabular-nums">
            {fmt(progress)}
          </div>
          <Slider
            className="w-36 sm:w-48"
            min={0}
            max={Math.max(duration, 1)}
            value={[Math.min(progress, duration)]}
            onValueChange={onSeekChange}
            onValueCommit={onSeekCommit}
            onPointerDown={onSeekStart}
            aria-label="Progreso"
          />
          <div className="text-muted-foreground w-[3.5rem] text-[12px] tabular-nums">
            {ready ? fmt(duration) : "–:–"}
          </div>
        </div>

        {/* Hidden audio element */}
        <audio
          ref={audioRef}
          src={track.audioUrl}
          preload="metadata"
          onLoadedMetadata={() => setDuration(audioRef.current?.duration || 0)}
          onTimeUpdate={() => {
            if (!seeking) setCurrent(audioRef.current?.currentTime || 0);
          }}
          onEnded={() => {
            setPlaying(false);
            setCurrent(0);
          }}
          onPlay={() => setPlaying(true)}
          onPause={() => setPlaying(false)}
        />
      </div>
    </TooltipProvider>
  );
}
