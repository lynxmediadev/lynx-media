
// ================================================
// File: src/app/player/page.tsx
// Test page to mount the reusable AudioPlayer component.
// ================================================
import type { Metadata } from "next";
import { AudioPlayer, type PlayerTrack } from "@/components/ui/AudioPlayer";

export const metadata: Metadata = {
  title: "Player demo | Lynx Media",
};

const demo: PlayerTrack = {
  id: "demo-001",
  title: "Golden Horizon (Demo)",
  artist: "Lynx Music Collective",
  audioUrl: "/audio/demo.mp3", // coloca un archivo de prueba en public/audio/demo.mp3
  coverUrl: "/images/covers/hero-bg-01.jpg", // usa una imagen existente en tu /public
  moods: ["Epic", "Emotional", "Elegant"],
  uses: ["TV", "Cine", "Publicidad", "Trailers", "Videojuegos"],
  shareUrl: "https://lynx-media.local/player/demo-001",
  artistUrl: "/catalog?artist=Lynx%20Music%20Collective",
  identifiers: { isrc: "CL-XYZ-25-00001" },
  rights: {
    master: "Lynx Media (One‑Stop)",
    publishingSplit: "100% Lynx Music Collective",
    licenseType: "No exclusiva",
    territories: "Worldwide",
    restrictions: ["Sin campañas políticas"],
    contentID: { enrolled: true, admin: "Identifyy", whitelist: "licensing@lynxmedia.cl" },
  },
};

export default function Page() {
  return (
    <main className="mx-auto w-full max-w-7xl px-3 sm:px-6 lg:px-10 xl:px-14 py-6">
      <h1 className="mb-4 text-[20px] md:text-[22px] font-bold tracking-tight">Player — Demo</h1>
      <p className="mb-4 text-[14.5px] text-muted-foreground">
        Este reproductor es reutilizable y seguirá la línea editorial de Lynx Media. La fila inferior está reservada para
        la barra de progreso y los tags; la fila superior contiene controles y acciones.
      </p>
      <AudioPlayer track={demo} />
    </main>
  );
}
