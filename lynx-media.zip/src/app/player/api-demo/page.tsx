// ================================================
// File: src/app/player/api-demo/page.tsx
// ================================================
import type { Metadata } from "next";
import { headers } from "next/headers";
import { AudioPlayer } from "@/components/ui/AudioPlayer";
import { playerTrackSchema, type PlayerTrackDTO } from "@/schema/track";
import { getJSON } from "@/lib/http";

export const metadata: Metadata = {
  title: "Player API demo | Lynx Media",
};

// ✅ headers() es SÍNCRONO — no uses await.
function absoluteUrl(path: string): string {
  const h = headers();
  const proto = h.get("x-forwarded-proto") ?? "http";
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  return `${proto}://${host}${path}`;
}

async function fetchTrack(id: string): Promise<PlayerTrackDTO> {
  const url = absoluteUrl(`/api/tracks/${id}`);
  const json = await getJSON<unknown>(url, { cache: "no-store" });
  return playerTrackSchema.parse(json);
}

export default async function Page() {
  const [t1, t2, t3] = await Promise.all([
    fetchTrack("demo-001"),
    fetchTrack("demo-002"),
    fetchTrack("demo-003"),
  ]);

  return (
    <main className="mx-auto w-full max-w-7xl px-3 py-6 sm:px-6 lg:px-10 xl:px-14">
      <h1 className="mb-4 text-[20px] font-bold tracking-tight md:text-[22px]">
        Player — API Demo
      </h1>

      <p className="mb-4 text-[14.5px] text-muted-foreground">
        Estos players consumen datos desde <code>/api/tracks/:id</code>, validados con Zod.
      </p>

      <div className="space-y-3">
        <AudioPlayer track={t1} />
        <AudioPlayer track={t2} />
        <AudioPlayer track={t3} />
      </div>
    </main>
  );
}
