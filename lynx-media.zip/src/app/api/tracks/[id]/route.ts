// ================================================
// File: src/app/api/tracks/[id]/route.ts
// Título: API Track por ID (GET /api/tracks/:id) con fallback a demos
// Descripción: Devuelve un track en formato PlayerTrackDTO (valida con Zod). Primero busca en BD;
//              si no existe, puede (opcional) devolver uno de los demos de la fase A.
// Qué hace: Permite que los nuevos tracks guardados por el admin aparezcan en el player,
//           sin romper las pruebas con demos.
// Peras y manzanas: “Primero miro en la base. Si no está, te doy el demo de prueba.”
// ================================================
import { type NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { playerTrackSchema } from "@/schema/track";
import { getTrackById as getDemo } from "@/mocks/track-store"; // fallback opcional

export const dynamic = "force-dynamic";

// Mapeo BD → DTO PlayerTrack
function mapDbToDTO(row: any) {
  return {
    id: row.id,
    title: row.title,
    artist: row.artist,
    audioUrl: row.audioUrl,
    coverUrl: row.coverUrl ?? undefined,
    moods: row.moods ?? [],
    uses: row.uses ?? [],
    shareUrl: undefined,
    artistUrl: undefined,
    identifiers: {
      isrc: row.isrc ?? undefined,
      iswc: row.iswc ?? undefined,
      upc: row.upc ?? undefined,
    },
    rights: {
      master: row.master ?? undefined,
      publishingSplit: row.publishingSplit ?? undefined,
      licenseType: row.licenseType ?? undefined,
      territories: row.territories ?? undefined,
      term: row.term ?? undefined,
      mediaBuy: row.mediaBuy ?? undefined,
      mfn: row.mfn ?? undefined,
      restrictions: row.restrictions ?? [],
      contentID: {
        enrolled: row.contentIdEnrolled ?? undefined,
        admin: row.contentIdAdmin ?? undefined,
        whitelist: row.contentIdWhitelist ?? undefined,
      },
    },
  };
}

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const id = params.id;

  // 1) Intentar BD
  const row = await prisma.track.findUnique({ where: { id } });
  if (row) {
    const dto = mapDbToDTO(row);
    const parsed = playerTrackSchema.safeParse(dto);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid track payload (DB)", code: "TRACK_SCHEMA_ERROR", issues: parsed.error.issues },
        { status: 500, headers: { "Cache-Control": "no-store" } }
      );
    }
    return NextResponse.json(parsed.data, { status: 200, headers: { "Cache-Control": "no-store" } });
  }

  // 2) Fallback demo (opcional)
  const fallback = getDemo(id);
  if (fallback) {
    const parsed = playerTrackSchema.safeParse(fallback);
    if (parsed.success) {
      return NextResponse.json(parsed.data, { status: 200, headers: { "Cache-Control": "no-store" } });
    }
  }

  // 3) Not found
  return NextResponse.json(
    { error: "Not Found", code: "TRACK_NOT_FOUND", id },
    { status: 404, headers: { "Cache-Control": "no-store" } }
  );
}
