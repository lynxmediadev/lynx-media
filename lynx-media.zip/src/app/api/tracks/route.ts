// ================================================
// File: src/app/api/tracks/route.ts
// Título: API de Tracks (GET lista y POST crear)
// Descripción: Lista todos los tracks existentes y crea uno nuevo con los datos del form.
// Qué hace: GET → devuelve array de tracks (para catálogo); POST → guarda metadata + asset en BD.
// Peras y manzanas: “Ver todo lo que hay” y “agregar una canción nueva”.
// ================================================
import { type NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { createTrackInput } from "@/schema/track-input";

export async function GET(_req: NextRequest) {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
  const rows = await prisma.track.findMany({
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json(rows, { status: 200, headers: { "Cache-Control": "no-store" } });
}

export async function POST(req: NextRequest) {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
  const json = await req.json();
  const parsed = createTrackInput.safeParse(json);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input", issues: parsed.error.issues }, { status: 400 });
  }
  const d = parsed.data;

  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
  const created = await prisma.track.create({
    data: {
      title: d.title,
      artist: d.artist,

      audioUrl: d.audio.url,
      coverUrl: d.coverUrl,
      moods: d.moods,
      uses: d.uses,

      isrc: d.isrc,
      iswc: d.iswc,
      upc: d.upc,

      master: d.rights?.master,
      publishingSplit: d.rights?.publishingSplit,
      licenseType: d.rights?.licenseType,
      territories: d.rights?.territories,
      term: d.rights?.term,
      mediaBuy: d.rights?.mediaBuy,
      mfn: d.rights?.mfn,
      restrictions: d.rights?.restrictions ?? [],
      contentIdEnrolled: d.rights?.contentIdEnrolled,
      contentIdAdmin: d.rights?.contentIdAdmin,
      contentIdWhitelist: d.rights?.contentIdWhitelist,

      assetKey: d.audio.key,
      assetMime: d.audio.mime,
      assetSize: d.audio.size,
    },
  });

  return NextResponse.json({ id: created.id }, { status: 201 });
}
