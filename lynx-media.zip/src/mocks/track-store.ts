// ================================================
// File: src/mocks/track-store.ts
// Mock store en memoria (para Fase A)
// ================================================
import type { PlayerTrack } from "@/domain/track";
import { DEMO_TRACK, makeDemoTrack } from "@/data/demo-track";

const DB = new Map<string, PlayerTrack>();

function seed(): void {
  if (DB.size) return;
  DB.set("demo-001", makeDemoTrack("demo-001"));
  DB.set("demo-002", makeDemoTrack("demo-002", { title: "Golden Horizon (Edit 60s)" }));
  DB.set("demo-003", makeDemoTrack("demo-003", { title: "Golden Horizon (Instrumental)" }));
}
seed();

export function getTrackById(id: string): PlayerTrack | null {
  return DB.get(id) ?? null;
}

export function listTracks(): PlayerTrack[] {
  return [...DB.values()];
}

// Útil más adelante para crear/actualizar desde el formulario admin
export function upsertTrack(track: PlayerTrack): void {
  DB.set(track.id, track);
}
