// ================================================
// File: src/lib/http.ts
// Título: Helper de fetch tipado (GET JSON)
// Descripción: Envuelve fetch para GET JSON con manejo simple de errores.
// Qué hace: Devuelve el cuerpo JSON tipado (T) o lanza un error con el status.
// Peras y manzanas: “Pego un grito (GET) y si no me contestan bien, lo aviso con un error claro.”
// ================================================
export async function getJSON<T>(input: string, init?: RequestInit): Promise<T> {
  const res = await fetch(input, {
    ...init,
    headers: { Accept: "application/json", ...(init?.headers ?? {}) },
  });
  if (!res.ok) {
    const msg = await res.text().catch(() => res.statusText);
    throw new Error(`[${res.status}] ${msg}`);
  }
  return res.json() as Promise<T>;
}
